package CS4Project;

public abstract class Equipment implements Interactive, Displayable{
    protected String name;
    protected String desc;
    protected double additionalHP;
    protected double additionalATK;
    protected double additionalDEF;
    protected double additionalMAGIC;
    protected double multiplierHP;
    protected double multiplierATK;
    protected double multiplierDEF;
    
    public Equipment(String n, String d, double additionalHP, double additionalATK, double additionalDEF, double additionalMAGIC, double multiplierHP, double multiplierATK, double multiplierDEF){
        this.name = n;
        this.desc = d;
        this.additionalHP = additionalHP;
        this.additionalATK = additionalATK;
        this.additionalDEF = additionalDEF;
        this.additionalMAGIC = additionalMAGIC;
        this.multiplierHP = multiplierHP;
        this.multiplierATK = multiplierATK;
        this.multiplierDEF = multiplierDEF;
    }
    
    public void addHP(double baseHP, double additionalHP){
        baseHP += additionalHP;
    }
    
    public void addATK(double baseATK, double additionalATK){
        baseATK += additionalATK;
    }
    
    public void addDEF(double baseDEF, double additionalDEF){
        baseDEF += additionalDEF;
    }
    
    public void addMAGIC(double baseMAGIC, double additionalMAGIC){
        baseMAGIC += additionalMAGIC;
    }
    
    public void multiHP(double baseHP, double multiplierHP){
        baseHP *= multiplierHP;
    }
    
    public void multiATK(double baseATK, double multiplierATK){
        baseATK *= multiplierATK;
    }
    
    public void multiDEF(double baseDEF,double multiplierDEF){
        baseDEF *= multiplierDEF;
    }
    
    public void pickUp(){
        System.out.println(name + " has now put in inventory.");
    }
    
    public void displayInformation(){
        System.out.println(desc);
    }
    
    public void inspect(){
        System.out.println("Name: " + name);
    }
    
}
