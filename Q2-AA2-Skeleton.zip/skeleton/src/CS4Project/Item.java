package CS4Project;

public class Item extends StoryProgressor{
    private boolean objectiveStatus;
    
    public Item(String c, String n, String d) {
        super(c, n, d);
        objectiveStatus =  false;
    }
    
    public void pickUp(){
        System.out.println("Item has been added to inventory.");
    }
    
    public void use(){
        System.out.println("Item has been used.");
    }
    
    public void changeObjectiveStatus(){
        if(objectiveStatus == true) objectiveStatus = false;
        else if(objectiveStatus == false) objectiveStatus = true;
    }
}
