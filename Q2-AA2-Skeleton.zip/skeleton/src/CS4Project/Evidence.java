package CS4Project;

public class Evidence extends StoryProgressor{
    private int progressUpdate;
    
    public Evidence(String c, String n, String d, int p){
        super(c, n, d);
        this.progressUpdate = p;
    }
    
    public void addEvidence(){
        System.out.println("Evidence has been used.");
    }
    
    public void addProgress(Character c){
        c.getProgress() += progressUpdate;
    }
}
