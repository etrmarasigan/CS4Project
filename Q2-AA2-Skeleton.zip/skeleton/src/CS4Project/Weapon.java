package CS4Project;

public class Weapon extends Equipment{
    private boolean equipStatus;
    
    public Weapon(String n, String d, double additionalHP, double additionalATK, double additionalDEF, double additionalMAGIC, double multiplierHP, double multiplierATK, double multiplierDEF){
        super(n, d, additionalHP, additionalATK, additionalDEF, additionalMAGIC, multiplierHP, multiplierATK, multiplierDEF);
        equipStatus = false;
    }
    
    public void changeEquipStatus(){
        if(equipStatus == true) equipStatus = false;
        else if(equipStatus == false) equipStatus = true;
    }
}
