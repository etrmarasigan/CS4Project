package CS4Project;

public class Enemy extends Entity implements Interactive{
    
    public Enemy(String n, double HP, double DEF, double ATK) {
        super(n, HP, DEF, ATK);
    }
    
    public void inspect(){
        System.out.println("Name: " + name);
        System.out.println("HP: " + baseHP);
        System.out.println("ATK: " + baseATK);
        System.out.println("DEF: " + baseDEF);
    }
    
    @Override
    public void dialogue() {
        System.out.println("Enemy speaks here");
    }
}
