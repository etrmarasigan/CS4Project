package CS4Project;

public interface Interactive {
  public void inspect();  
}
