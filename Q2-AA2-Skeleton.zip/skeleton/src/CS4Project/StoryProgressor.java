package CS4Project;

public abstract class StoryProgressor implements Interactive, Displayable{
    protected String content;
    protected String name;
    protected String desc;
    
    public StoryProgressor(String c, String n, String d){
        this.content =  c;
        this.name = n;
        this.desc = d;
    }
    
    public void inspect(){
        System.out.println("Name: " + name);
        System.out.println("Content: " + content);
    }
    
    public void displayInformation(){
        System.out.println(desc);
    } 
    
}
