package CS4Project;

public class Skeleton {
    public static void main(String[] args) {
        
      Weapon queensGambit = new Weapon("Queen's Gambit", "A bow.", 0, 25, 0, 0, 0, 0, 0);
      Weapon fadeout = new Weapon("Fadeout", "A bow.", 0, 10, 0, 0, 0, 0, 0);
      Weapon magicSlate = new Weapon("MagicSlate", "A tablet.", 25, 0, 0, 0, 0, 0, 0);
      Weapon lightningStride = new Weapon("Lightning Stride", "A sword.", 0, 0, 25, 0, 0, 0, 0);
      Weapon starling = new Weapon("Starling", "A sickle.", 0, 0, 0, 10, 0, 0, 0);
      
      Character ivara = new Character("Ivara", 100, 20, 25, queensGambit, "Main DPS", 30);  
      Character akasi = new Character("Akasi", 150, 25, 15, magicSlate, "Healer", 20); 
      Character ozran = new Character("Ozran", 200, 40, 10, lightningStride, "Support", 30); 
      Character aila = new Character("Aila", 100, 25, 15, starling, "Support", 40); 
      
      Enemy callum = new Enemy("Callum", 490, 25, 15);
      
      Item hammer = new Item("content", "Hammer", "A hammer... to smash something?");
      
      //Scenario #1
      System.out.println("Scenario #1");
      ivara.engageBattle(callum);
      ivara.equipWeapon(queensGambit);
      ivara.engageBattle(callum);
      ivara.basicAttack(callum);
      ivara.checkHealth(callum);
      akasi.basicAttack(callum);
      akasi.checkHealth(callum);
      ozran.basicAttack(callum);
      ozran.checkHealth(callum);
      aila.basicAttack(callum);
      aila.checkHealth(callum);
      
      //Scenario #2
      System.out.println("\nScenario #2");
      ivara.interact(fadeout);
      ivara.unequipWeapon(queensGambit);
      queensGambit.changeEquipStatus();
      ivara.equipWeapon(fadeout);
      fadeout.changeEquipStatus();
      
      //Scenario #3
      System.out.println("\nScenario #3");
      akasi.interact(hammer);
      hammer.displayInformation();
      hammer.pickUp();
      hammer.use();
    }
    
}
