package CS4Project;

public class Consumable extends Equipment{
    private double duration;
    
    public Consumable(String n, String d, double additionalHP, double additionalATK, double additionalDEF, double additionalMAGIC, double multiplierHP, double multiplierATK, double multiplierDEF, int du){
        super(n, d, additionalHP, additionalATK, additionalDEF, additionalMAGIC, multiplierHP, multiplierATK, multiplierDEF);
        this.duration = du;
    }
    
    public void consume(Consumable c){
        System.out.println("You have consumed " + c.name + " for " + c.duration + " seconds.");
    }
}
