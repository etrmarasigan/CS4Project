package CS4Project;

public class Character extends Entity{
    private Weapon weapon;
    private String role;
    private int progress;
    private double baseMAGIC;
    
    public Character(String n, double HP, double DEF, double ATK, Weapon w, String r, double MAGIC){
        super(n, HP, DEF, ATK);
        this.weapon = w;
        this.role = r;
        this.progress = 0;
        this.baseMAGIC = MAGIC;
    }
    
    public void equipWeapon(Weapon w){
       weapon = w;
       System.out.println(w.name + " has been equipped.");
    }
    
    public void unequipWeapon(Weapon w){
       weapon = w;
       System.out.println(w.name + " has been unequipped.");
    }
    
    public void specialSkill(Character c){        
        if(baseMAGIC != 100) System.out.println("You can't use this yet.");
        else{
            if("Ivara".equals(c.name)){
                c.baseATK *= 1.5;
            }
        }
    }
    
    public void specialSkill(Character c, Character target){ 
        if(baseMAGIC != 100) System.out.println("You can't use this yet.");
        else{
            if("Akasi".equals(c.name)){
                target.baseHP += c.baseHP*0.5;
            }
            if("Ozran".equals(c.name)){
                target.baseDEF += c.baseDEF*0.6;
            }
            if("Aila".equals(c.name)){
                target.baseMAGIC += 30;
            }
        }
    }
    
    public void engageBattle(Enemy e){
        System.out.println("You have engaged " + e.name + " in battle. What do you want to do?");
    }
    
    public void checkHealth(Enemy e){
        if (e.baseHP <= 0) {
            System.out.println("You have defeated the enemy.");
        }
    }
    
    public void interact(Interactive i){
        i.inspect();
    }

    @Override
    public void dialogue() {
        System.out.println("Character speaks here");
    }
    
    public int getProgress(){
        return progress;
    }
}
