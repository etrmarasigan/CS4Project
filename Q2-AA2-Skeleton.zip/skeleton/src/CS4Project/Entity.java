package CS4Project;

public abstract class Entity {
    protected String name;
    protected double baseHP;
    protected double baseDEF;
    protected double baseATK;
    
    public Entity(String n, double HP, double DEF, double ATK){
        this.name = n;
        this.baseHP = HP;
        this.baseATK = ATK;
        this.baseDEF = DEF;
    }
    
    public void basicAttack(Entity e){
        e.baseHP -= baseHP;
        System.out.println(name + " attacked " + e.name + ".");
    }    
    public abstract void dialogue();

}