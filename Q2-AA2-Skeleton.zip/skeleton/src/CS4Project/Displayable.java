package CS4Project;

public interface Displayable {
    public void displayInformation();
}
